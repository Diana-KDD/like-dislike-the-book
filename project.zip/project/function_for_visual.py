from information import*
from functions_for_NS import*

def flipping_pages(flipping_speed, forward = True):                  # Листание страниц

    if forward:
        pages = book_array[12:16]
    else:
        pages = book_array[16:12:-1]    
    nn2.play(page_flip, -1)
    for sprite in pages:
        clock.tick(flipping_speed)

        sprite = pg.transform.scale_by(sprite, size_book)

        window.blit(sprite, (x_book, y_book)) 
             
        pg.display.update() 
        window.blit(background_table, (0, 0))
    nn2.stop()    

def animation_first_part(forward = True):  # Открытие/Закрытие книги
    
    if forward:
        shots = book_array[:12]
        music_start = shots[6]
        music_stop = shots[-1]
    else:
        shots = book_array[12::-1]
        music_start = shots[0]
        music_stop = shots[6]

    nn2.play(page_flip, -1)

    for sprite in shots:                   #используются кадры до/от первой перелистанной страницы
        clock.tick(7)
            
        sprite = pg.transform.scale_by(sprite, size_book)

        window.blit(sprite, (x_book, y_book)) 
              
        pg.display.update() 
        window.blit(background_table, (0, 0))
    nn2.stop()
         
def transparent_background(changes_transparency, lies_under, x_y):  # Меняется прозрачность фона

    for tr in transparency:
        clock.tick(12)

        changes_transparency.set_alpha(tr)
        window.blit(changes_transparency, x_y) 
             
        pg.display.update() 
        window.blit(background_table, (0, 0))                  
        
        if tr == transparency[-1]:         
            sprite = pg.transform.scale_by(lies_under, size_book)  
            window.blit(sprite, (x_book, y_book)) 
            pg.display.update()  
            break
        else:
            sprite = pg.transform.scale_by(lies_under, size_book)    #Отображается за прозрачным фоном, пока фон не стал полностью прозрачным
            window.blit(sprite, (x_book, y_book))            

def text_animation(heading, shot, points = [], y = height_book * (170 / 1000)):            # Анимация написания текста (Заголовок и пункты)
    global book_array

    x_y_cell.clear()

    nn3.play(write, -1)

    for line in heading:
        x_heading = width_book * (100 / 1034)
        for symbol in line:
            clock.tick(7)

            symbol_heading = font_text_heading.render(symbol, 1, color_font_pages)
            symbol_heading = pg.transform.scale_by(symbol_heading, 1)

            width_symbol = symbol_heading.get_width()

            shot.blit(symbol_heading, (x_heading, y))
            window.blit(shot, (x_book, y_book))
            pg.display.update()
            window.blit(background_table, (0, 0))

            x_heading += width_symbol
        y += height_book * (45 / 1000)   

    #--------------------------------------------------------------------------------------------------------------

    y += height_book * (35 / 1000)

    for line in points:
        x_points = width_book * (100 / 1034)
        for symbol in line:
            clock.tick(7)

            symbol_points = font_text_points.render(symbol, 1, color_font_pages)
            symbol_points = pg.transform.scale_by(symbol_points, 1)

            width_symbol = symbol_points.get_width()

            shot.blit(symbol_points, (x_points, y))
            window.blit(shot, (x_book, y_book))
            pg.display.update()
            window.blit(background_table, (0, 0))

            x_points += width_symbol

        y += height_book * (3 / 1000)  
        x_points = width_book * (100 / 1034) + width_book * (350 / 1034)   

        shot.blit(cell, (x_points, y))

        window.blit(shot, (x_book, y_book))

        pg.display.update()
        window.blit(background_table, (0, 0))

        x_y_cell.append([ x_book + x_points, y + y_book])    
        
        y += height_book * (70 / 1000)     
    
    book_array.append(shot)            #Забрасываем последний кадр(на котором уже прицеплен текст и квадратики) в конец списка кадров
    nn3.pause()

    return x_y_cell
    return book_array

def start():
    global number_clicks_start, Start_not_pressed, passed_this_function, status_buttons

    x_y_mouse = pg.mouse.get_pos()                   #Координаты мыши
    condition_mouse = pg.mouse.get_pressed()         #Отслеживание клика
    
    if x_start_btn <= x_y_mouse[0] <= x_start_btn + start_btn_width \
        and y_start_btn <= x_y_mouse[1] <= y_start_btn + start_btn_height \
        and condition_mouse[0] == True and number_clicks_start == 0:                #Клик произошел
        
        status_buttons[0] = True
        Start_not_pressed = False
        number_clicks_start += 1

        book_animation()

        passed_this_function = True
        

    if Start_not_pressed == True:                                                   #Пока клик НЕ произошел
        
        main_background_alpha.fill((0, 0, 0, 235))
        
        window.blit(background_table, (0, 0))

        sprite = pg.transform.scale_by(book_array[0], size_book)
        window.blit(sprite, (x_book, y_book))

        window.blit(main_background_alpha, (0, 0)) 

        window.blit(start_btn, (x_start_btn, y_start_btn))  
    return passed_this_function    

def Continue_btn():
    global number_clicks_further, choice_cell,Important_in_the_book, Observe_in_the_book, result
    x_y_mouse = pg.mouse.get_pos()                   #Координаты мыши
    condition_mouse = pg.mouse.get_pressed()         #Отслеживание клика
    
    if x_further_btn + x_book <= x_y_mouse[0] <= x_further_btn + x_book + further_btn_width \
        and y_further_btn + y_book <= x_y_mouse[1] <= y_further_btn + y_book + further_btn_height \
        and condition_mouse[0] == True:              #Клик произошел
        
        number_clicks_further += 1

        sp = book_array[-1]
        inn = 0
        for opop in choice_cell:
            if opop:
                sp.blit(check_mark, (x_y_cell[inn][0] - x_book, x_y_cell[inn][1] - (y_book + (10 * size_book))))      #(450, 288)
            inn += 1
        
        if number_clicks_further == 1:
            status_buttons[1] = True
            status_criteria.append(choice_cell)
            choice_cell = [False, False, False, False, False, False, False]

            Important_in_the_book = converting_numbers(status_criteria[0])
            
            getting_the_required_response(epoch, Important_in_the_book, responses)
        else:
            status_criteria.append(choice_cell)

            status_buttons[2] = True  

            Observe_in_the_book = converting_numbers(status_criteria[1])
        
        book_animation()
        
    if number_clicks_further < 2:   #реакция на маленькие книпки
        ertert = choice()
        check_marks(ertert) 

    return Important_in_the_book, Observe_in_the_book
    
def check_marks(choice_cel):
        global x_y_cell
        
        inn = 0
        coordinates_checkmark = []
        for j in choice_cel:
            
            if j == True:
                coordinates_checkmark.append((x_y_cell[inn][0], x_y_cell[inn][1] - 10 * size_book))         
            inn += 1
        
        
        pg.display.update()  
        window.blit(background_table, (0, 0))    
        window.blit(book_array[-1], (x_book, y_book))   

        for opop in coordinates_checkmark:
            window.blit(check_mark, opop) 
            nn4.play(check_mark_m)  

def choice():
    
    x_y_mouse = pg.mouse.get_pos()                   #Координаты мыши
    condition_mouse = pg.mouse.get_pressed()         #Отслеживание клика
    rgg = choice_cell
    for i in x_y_cell:
        
        if i[0] <= x_y_mouse[0] <= i[0] + cell_size \
            and i[1] <= x_y_mouse[1] <= i[1] + cell_size \
            and condition_mouse[0] == True:                #Клик произошел
            
            rgg[x_y_cell.index(i)] = not(rgg[x_y_cell.index(i)])
    
    return rgg
            
def book_animation():
    global flipping_speed_2, transparency, font_text_heading, popo_2


    if status_buttons[0] == True:

        pg.mouse.set_visible(False)

        transparent_background(main_background_alpha, book_array[0], (0, 0))
        window.blit(background_table, (0, 0))
        
        animation_first_part()

        for i in range(4):                                                          # Перелистывание страниц
            flipping_pages(flipping_speed_1)
    
        sprite = pg.transform.scale_by(book_array[16], size_book)                           # Последний открывшийся кадр страницы 
        window.blit(sprite, (x_book, y_book))
        pg.display.update() 
        window.blit(background_table, (0, 0))
        
        text_animation(text_criteria_heading, sprite, criterias)                    # Анимация текста (кроме самого текста передается и последний кадр)

        book_array[-1].blit(further_btn, (x_further_btn, y_further_btn))
        window.blit(book_array[-1], (x_book, y_book))
        pg.display.update()
        
        pg.mouse.set_visible(True)

        status_buttons[0]= False               
    
    #--------------------------------------------------------------------------------------------------------------
    
    if status_buttons[1] == True or status_buttons[2] == True:
        
        pg.mouse.set_visible(False)    

        transparent_background(book_array[-1], book_array[16], (x_book, y_book))
        window.blit(background_table, (0, 0))

        if status_buttons[1] == True:
            
            for tic in range (flipping_speed_2, 12, 2):
                for i in range(3):
                    flipping_pages(tic)    

            sprite = pg.transform.scale_by(book_array[16], size_book)                 # Последний открывшийся кадр страницы 
            window.blit(sprite, (x_book, y_book))
            pg.display.update()  
            window.blit(background_table, (0, 0)) 
            
            

            text_animation(text_criteria_heading_2, sprite, criterias)  
            
            book_array[-1].blit(further_btn, (x_further_btn, y_further_btn))   # Приклеиваем кнопку "Продолжить" на последний слайд
            window.blit(book_array[-1], (x_book, y_book))
            pg.display.update()
            
            pg.mouse.set_visible(True)  

            status_buttons[1] = False
        
        #--------------------------------------------------------------------------------------------------------------
        
        if status_buttons[2] == True:  

            font_text_heading = pg.font.Font("fonts\\Annabelle.ttf", int(width_book // (1034 // 55)))  

            for tic in range (flipping_speed_2, 12, 2):
                for i in range(3):
                    flipping_pages(tic) 

            sprite = pg.transform.scale_by(book_array[16], size_book)    #Последний открывшийся кадр страницы 
            window.blit(sprite, (x_book, y_book))
            pg.display.update()  
            window.blit(background_table, (0, 0)) 

            text_animation(loading, sprite, y = height_book * (450 / 1000)  )  

            
            for i in range(3):
                transparent_background(book_array[-1], book_array[16], (x_book, y_book))
                
                sprite = pg.transform.scale_by(book_array[16], size_book)    #Последний открывшийся кадр страницы 
                window.blit(sprite, (x_book, y_book))
                pg.display.update() 
                if i == 2:
                    break
                transparency = transparency[::-1]
             
            window.blit(background_table, (0, 0)) 

            train(epoch, count_layer, skelet_neural_network, responses, neurons_layers)
            output_values = Output_values(Observe_in_the_book, count_layer, skelet_neural_network)

            if output_values[-1] > 0.5:
                result = result = ["Книга вам",
                                  "понравится!"]
            elif output_values[-1] == 0.5:
                result = result = ["Книга вам",
                                   "возможно",
                                   "понравится"]
            elif output_values[-1] < 0.5:
                result = result = ["Книга вам",
                                   "не понравится",
                                   "      :("]
                                 

            text_animation(result, sprite, y = height_book * (420 / 1000)  ) 
            nn5.play(res)

            window.blit(book_array[-1], (x_book, y_book))
            pg.display.update() 

            pg.time.wait(5000)

            transparent_background(book_array[-1], book_array[16], (x_book, y_book))

            for i in range(7):
                flipping_pages(flipping_speed_1, False)

            animation_first_part(forward=False)

            transparency = transparency[::-1]
            transparent_background(main_background_alpha, book_array[0], (0, 0))

            main_background_alpha.fill((0, 0, 0, 235))
            window.blit(background_table, (0, 0))

            sprite = pg.transform.scale_by(book_array[0], size_book)
            window.blit(sprite, (x_book, y_book))  
            window.blit(main_background_alpha, (0, 0)) 
            
            status_buttons[2] = False
            pg.mouse.set_visible(True) 
     
def converting_numbers(list_False_True):
    list_1_0 = []
    for i in list_False_True:
        if i == True:
            list_1_0.append(1)  
        if i == False:
            list_1_0.append(0)    
    return list_1_0            

epoch = creating_an_observation_vector(neurons_layers)
skelet_neural_network = creating_origina_weights(count_layer, neurons_layers)
