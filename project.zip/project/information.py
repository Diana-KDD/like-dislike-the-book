import pygame as pg
pg.init()
pg.font.init()
import numpy as np
import random

# Главное окно
#w_width = 1535
w_width = 1835
w_height = w_width * 0.525

window = pg.display.set_mode((w_width, w_height))

# Картинка стола на фоне
background_table = pg.image.load("pictures\\table.png")
scaling_image = (w_width + 100, w_height)
background_table = pg.transform.scale(background_table, scaling_image)

# Загрузка картинок книги для анимации
book_array = [pg.image.load("pictures\\book" + str(i + 1)+ ".png") for i in range(17)]

size_book = w_width / 1535

width_book = book_array[0].get_width()* size_book
height_book = book_array[0].get_height() * size_book

x_book = (w_width // 2) - (width_book //2)
y_book = (w_height // 2) - (height_book // 2)

# Иконка и название окна
pg.display.set_icon(book_array[12])
pg.display.set_caption("Понравится/ не понравится вам книга?")

# Часики
clock = pg.time.Clock()

flipping_speed_1 = 8
flipping_speed_2 = 5

# Кнопка старт
start_btn_width = w_width / 5
start_btn_height = w_height / 12

color_start_btn = (177, 134, 111)

start_btn = pg.Surface((start_btn_width, start_btn_height))
start_btn.fill(color_start_btn)

x_start_btn = (w_width // 2) - (start_btn_width // 2)
y_start_btn = (w_height // 2) - (start_btn_height // 2)

Start_not_pressed = True
number_clicks_start = 0

# Кнопка далее
further_btn_width = w_width / 5
further_btn_height = w_height / 12

color_further_btn = (192, 192, 192)

further_btn = pg.Surface((further_btn_width, further_btn_height))
further_btn.fill(color_further_btn)

x_further_btn = (w_width // 2) - (further_btn_width // 2)
y_further_btn = height_book - height_book * 0.325

further_not_pressed = True

# Черный полупрозрачный фон
main_background_alpha = pg.Surface((w_width, w_height))
main_background_alpha = main_background_alpha.convert_alpha()

transparency = [i for i in range(230,-5, -5)]

# Текст
# Настройки текса
color_font_start = (219, 199, 189)
color_font_further = (130, 130, 130)
color_font_pages = (0, 0, 0)

d1 =width_book // (1034 // 65)
d2= width_book // (1034 // 45)
d3 =width_book // (1034 // 35)
d4 =width_book // (1034 // 25)

font_text_start = pg.font.Font("fonts\\FETesto.ttf", int(d1))
font_text_further = pg.font.Font("fonts\\FETesto.ttf", int(d2))

font_text_heading = pg.font.Font("fonts\\Annabelle.ttf", int(d3))                            
font_text_points = pg.font.Font("fonts\\Annabelle.ttf", int(d4))

# Текст кнопки старт
start_text = font_text_start.render("старт", 1, color_font_start)

start_text_width = start_text.get_width()
start_text_height = start_text.get_height()

x_start_text = (start_btn_width // 2) - (start_text_width // 2)
y_start_text = (start_btn_height // 2) - (start_text_height // 2)

start_btn.blit(start_text, (x_start_text, y_start_text))

# Текст кнопки продолжить
further_text = font_text_further.render("Продолжить", 1, color_font_further)

further_text_width = further_text.get_width()
further_text_height = further_text.get_height()

x_further_text = (further_btn_width // 2) - (further_text_width // 2)
y_further_text = (further_btn_height // 2) - (further_text_height // 2)

further_btn.blit(further_text, (x_further_text, y_further_text))

number_clicks_further = 0

# Для всех кнопок
status_buttons = [False, False, False]   # Кнопка (старт, продолжить, продолжить)

# Текст страниц
text_criteria_heading = ["Что вам важно",
                        "в книге?"]

text_criteria_heading_2 = ["Что вам интересно",
                        "в этой книге?"]

loading = ["Загрузка..."]

result = ["Книга вам",
          "понравится!"]

criterias = ["1. Жанр",
             "2. Обложка и дизайн",
             "3. Сюжет/описание",
             "4. Объём",
             "5. Наличие картинок",
             "6. Автор",
             "7. Рейтинг и отзывы"]

# Клеточка
cell_size = width_book * (25/book_array[0].get_width())
cell = pg.image.load("pictures\\cell.png")
cell = pg.transform.scale(cell, (cell_size, cell_size))

x_y_cell = []

check_mark = pg.image.load("pictures\\Checki.png")
check_mark = pg.transform.scale_by(check_mark, size_book)

choice_cell = [False, False, False, False, False, False, False]

status_criteria = []

passed_this_function = False

# Музыка
page_flip = pg.mixer.Sound("music\\page_flip.mp3")
background = pg.mixer.Sound("music\\background.mp3")
write = pg.mixer.Sound("music\\pismo.mp3")
check_mark_m = pg.mixer.Sound("music\\check_marks.mp3")
res = pg.mixer.Sound("music\\res.mp3")

nn1 = pg.mixer.Channel(0)
nn2 = pg.mixer.Channel(1)
nn3 = pg.mixer.Channel(2)
nn4 = pg.mixer.Channel(3)
nn5 = pg.mixer.Channel(4)

nn1.set_volume(0.2)
nn2.set_volume(1)
nn3.set_volume(0.4)
nn4.set_volume(1)
nn5.set_volume(1)

nn1.play(background, -1)

# НЕЙРОСЕТЬ

# То, что нам важно в книге
x_1 = 0  # Жанр книги
x_2 = 0  # Обложка и дизайн книги
x_3 = 1  # Сюжет и описание книги
x_4 = 0  # Объём книги
x_5 = 0  # Наличие иллюстраций, графический элементов, таблиц
x_6 = 0  # Автор книги
x_7 = 0  # Рейтинг книги и отзывы
"""Important_in_the_book = [x_1, 
                         x_2, 
                         x_3, 
                         x_4, 
                         x_5, 
                         x_6, 
                         x_7]"""
Important_in_the_book = []
# То, что мы наблюдаем в книге
see_x_1 = 0
see_x_2 = 1
see_x_3 = 0
see_x_4 = 1
see_x_5 = 1
see_x_6 = 1
see_x_7 = 1
"""Observe_in_the_book = [see_x_1, 
                       see_x_2, 
                       see_x_3, 
                       see_x_4, 
                       see_x_5, 
                       see_x_6, 
                       see_x_7]"""
Observe_in_the_book = []

count_layer = 5                                       #Сколько слоев всего (минимум 2 (входящий и выходящий))
neurons_layers = [7, 6, 3, 2, 1]                      #Количество нейронов в каждом слое последовательно

#change_number_neurons = bool(input("хотите изменить количество нейронов? True/False: \n"))
change_number_neurons = False

if neurons_layers == [] or change_number_neurons == True:        #Количество нейронов в каждом слое последовательно (вводятся через терминал)
    neurons_layers.clear()
    for i in range(count_layer):
        n = int(input(f"Сколько нейронов в {i + 1} слое? "))
        neurons_layers.append(n)

responses = []