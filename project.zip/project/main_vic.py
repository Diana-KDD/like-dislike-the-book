from function_for_visual import*

is_ran = True
while is_ran:
    
    for event in pg.event.get():
        if event.type == pg.QUIT:
            is_ran = False
    
    passed_this_function = start()
    if passed_this_function == True:
        Important_in_the_book,Observe_in_the_book = Continue_btn()   
    pg.display.flip()