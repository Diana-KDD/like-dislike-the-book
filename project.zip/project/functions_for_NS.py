from information import*

def creating_an_observation_vector(neurons_layers):
    # создаем вектор наблюдения (64 разных вариантов)
    the_observation_vector = np.array([[0 for j in range\
        (neurons_layers[0])] for i in range(64)])
    for i in range(64):
        count_1 = random.randint(0, neurons_layers[0])
        for ed in range(count_1):
            while True:
                random_index_1 = random.randint(0, neurons_layers[0] - 1)
                if the_observation_vector[i][random_index_1] == 0:
                    the_observation_vector[i][random_index_1] = 1
                    break
    return  the_observation_vector

def getting_the_required_response(the_observation_vector, Important_in_the_book, response):
  # Получаем требуемый отклик
    for vector in the_observation_vector:
        index = 0                        # Индекс
        criteria_met = 0                 # Соблюденные критерии
        criteria_of_no_interest = 0      # Критерии, что нас не интересуют, но они истины
        required_response = 0            # Требуемый отклик
        
        for criteria in Important_in_the_book:
            if criteria == 1:
                if vector[index] == criteria:
                    criteria_met += 1
            else:
                if vector[index] == 1:
                    criteria_of_no_interest += 1    
            index += 1

        if criteria_met == Important_in_the_book.count(1):
            required_response = 1

        elif criteria_met > Important_in_the_book.count(1) // 2:
            required_response = 1

        elif criteria_met == Important_in_the_book.count(1) // 2:
            if criteria_of_no_interest > Important_in_the_book.count(0) // 2:
                required_response = 1
            else:
                required_response = 0

        elif criteria_met == 0:
            required_response = 0

        elif criteria_met < Important_in_the_book.count(1) // 2:
            required_response = 0   

        response.append(required_response)
    
    return response

def creating_origina_weights(count_layer, neurons_layers):
    # создаем небольшой скелет НС с рандомными первоначальными весами
    skelet_neural_network = []
    for layer in range(count_layer - 1):        #Убираем входящий слой
        number_neurons_layer = neurons_layers[layer+1]
        number_weight = neurons_layers[layer]
        l = np.array([[random.uniform(-0.5, 0.5) for j in range(number_weight)] for i in range(number_neurons_layer)])
        skelet_neural_network.append(l)
    return skelet_neural_network  

def f(x):
  # Сигмоидная функция активации: f(x) = 1 / (1 + e^(-x))
  return 1 / (1 + np.exp(-x))

def df(x):
  # Производная сигмоиды: f'(x) = f(x) * (1 - f(x))
  return x * (1 - x) 

def Output_values(vector, count_layer, skelet_neural_network ): 
    #Проходим по НС и получем выходные значения с каждого скрытого слоя и конечный результат НС
    output_values = [vector]

    for layer in range(count_layer - 1):     #Убираем входной слой
        h2 = np.dot(skelet_neural_network[layer], output_values[-1])
        h2_out = np.array([f(x) for x in h2])
        output_values.append(h2_out)
    return output_values

# Само обучение
def train(epoch, count_layer, skelet_neural_network, response, neurons_layers):
  convergence_step = 0.01        # шаг обучения
  N = 10000                      # число итераций при обучении
  count = len(epoch)
  for iteration in range(N):
    for number in range(0, count):
        vector = epoch[number]                                                                   
        output_values = Output_values(vector, count_layer, skelet_neural_network )        # прямой проход по НС и вычисление выходных значений нейронов
        
        error = output_values[-1] - response[number]                                      # ошибка
        
        delta = np.array([error * df(output_values[-1])])                                 # локальный градиент

        for i in range(1, count_layer):
            number_neurons = neurons_layers[-i]
            w_layer = skelet_neural_network[-i]
            for j in range(number_neurons):
                w_layer[j, :] = w_layer[j, :] - output_values[-i - 1] * delta[j] * convergence_step
            if (count_layer - 1) == i:
                break    
            delta_by_weight = np.array([w_layer[j, :] * delta[j] for j in range(number_neurons)]) 
            total = 0    
            for n in delta_by_weight:
                total += n 
            delta = total * df(output_values[-i - 1])    
